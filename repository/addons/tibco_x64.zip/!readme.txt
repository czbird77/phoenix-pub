If you want to use JMS calls from Phoenix to Tibco EMS,
copy all the libraries from this folder to your local Phoenix folder (where phoenix.exe is).
